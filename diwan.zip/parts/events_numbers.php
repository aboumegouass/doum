<div class="event-counts">
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-sm-6">
                <div class="event-count-item">
                    <h1 class="count-title">3.4</h1>
                    <p class="text">Million Dinars, The volume of investments</p>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6">
                <div class="event-count-item">
                    <h1 class="count-title">+500</h1>
                    <p class="text">Direct job opportunities we provided</p>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6">
                <div class="event-count-item">
                    <h1 class="count-title">+350</h1>
                    <p class="text">Teams trained</p>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6">
                <div class="event-count-item">
                    <h1 class="count-title">150</h1>
                    <p class="text">Incubated startups</p>
                </div>
            </div>
        </div>
    </div>
</div>