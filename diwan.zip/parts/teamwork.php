<div class="teams-items">
    <div class="container">
        <div class="teams-header">
            <h1 class="title">فريق العمل</h1>
        <p class="text">لدينا الكثير والكثير لكم فما ترونه الان على الموقع الخاص بنا ما هو إلا قطرة من بحر الافكار التى
            نمتلكها</p>
        </div>
        <div class="row py-5">
            <div class="col-md-3">
                <div class="team-item">
                    <div class="team-item-img">
                        <img src="<?php echo get_template_directory_uri() . '/img/placeholder.jpeg'; ?>" alt="">
                    </div>
                    <div class="team-item-content">
                        <h3 class="title">بدون اسم</h3>
                        <p class="text">المدير التنفيذي</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="team-item">
                    <div class="team-item-img">
                        <img src="<?php echo get_template_directory_uri() . '/img/placeholder.jpeg'; ?>" alt="">
                    </div>
                    <div class="team-item-content">
                        <h3 class="title">بدون اسم</h3>
                        <p class="text">المدير التنفيذي</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="team-item">
                    <div class="team-item-img">
                        <img src="<?php echo get_template_directory_uri() . '/img/placeholder.jpeg'; ?>" alt="">
                    </div>
                    <div class="team-item-content">
                        <h3 class="title">بدون اسم</h3>
                        <p class="text">المدير التنفيذي</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="team-item">
                    <div class="team-item-img">
                        <img src="<?php echo get_template_directory_uri() . '/img/placeholder.jpeg'; ?>" alt="">
                    </div>
                    <div class="team-item-content">
                        <h3 class="title">بدون اسم</h3>
                        <p class="text">المدير التنفيذي</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="team-item">
                    <div class="team-item-img">
                        <img src="<?php echo get_template_directory_uri() . '/img/placeholder.jpeg'; ?>" alt="">
                    </div>
                    <div class="team-item-content">
                        <h3 class="title">بدون اسم</h3>
                        <p class="text">المدير التنفيذي</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="team-item">
                    <div class="team-item-img">
                        <img src="<?php echo get_template_directory_uri() . '/img/placeholder.jpeg'; ?>" alt="">
                    </div>
                    <div class="team-item-content">
                        <h3 class="title">بدون اسم</h3>
                        <p class="text">المدير التنفيذي</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="team-item">
                    <div class="team-item-img">
                        <img src="<?php echo get_template_directory_uri() . '/img/placeholder.jpeg'; ?>" alt="">
                    </div>
                    <div class="team-item-content">
                        <h3 class="title">بدون اسم</h3>
                        <p class="text">المدير التنفيذي</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="team-item">
                    <div class="team-item-img">
                        <img src="<?php echo get_template_directory_uri() . '/img/placeholder.jpeg'; ?>" alt="">
                    </div>
                    <div class="team-item-content">
                        <h3 class="title">بدون اسم</h3>
                        <p class="text">المدير التنفيذي</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>