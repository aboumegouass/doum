<div class="app-header-bg" style="background-image: url('<?php echo get_template_directory_uri() . '/img/16_3.jpg'; ?>');">
    <div class="container">
        <h1 class="title">نبذة عنا</h1>
        <p class="text">لدينا الكثير والكثير لكم فما ترونه الان على الموقع الخاص بنا ما هو إلا قطرة من بحر الافكار التى
            نمتلكها</p>
    </div>
</div>

<div class="container my-3">
        <div class="abouts-items">
    <div class="row py-5">
        <div class="col-md-4">
            <div class="about-item">
                <div class="about-item-img">
                    <img src="<?php echo get_template_directory_uri() . '/img/click.gif'; ?>" alt="">
                </div>
                <div class="about-item-content">
                    <h3 class="title">مهمتنا</h3>
                    <p class="text">تحقيق الريادة في الاعﻤﺎل باستخدام معرفتنا وخبراتنا وعلاقاتنا اًلاستراتيجية
                        لتحقيق أفضل النتائج لًكافة الاحداث ونسعى إلى تحقيق أهدافنا المتمثلة في رًفع مستوىً الاحداث
                        الخاصة وكافة الخدمات المقدمة، من خًلال تحقيق أهداف عملاءنا والمشاركﻴﻦ</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="about-item">
                <div class="about-item-img">
                    <img src="<?php echo get_template_directory_uri() . '/img/idea.gif'; ?>" alt="">
                </div>
                <div class="about-item-content">
                    <h3 class="title">رؤيتنا</h3>
                    <p class="text">أن نصبح الأولً في ما نفعله وننشرً الابداع ونترك البصمة المؤثرة .فى كل أرجاء
                        المملكه العربية السعوديه والوطنالعربى كما أننا نسعى دائماً إلى العالميه</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="about-item">
                <div class="about-item-img">
                    <img src="<?php echo get_template_directory_uri() . '/img/mailing.gif'; ?>" alt="">
                </div>
                <div class="about-item-content">
                    <h3 class="title">رسالتنا</h3>
                    <p class="text">تقديم الافكار المتألقة بأعلى معايﻴﺮ الجودة في الخدمات والارتقاء ﺑﻤستوى عالي
                        لتحقيق الاهداف المرجو ة لما يتم تنفيذه والتميز في الابداع و تلبية كافة القيم المضافة لاي حدث
                        والتفوق على التوقعات</p>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>