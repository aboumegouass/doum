<div class="col-xl-4 col-md-5">
    <div class="animated-img">
        <img src="<?php echo get_template_directory_uri() . '/img/conta.webp'; ?>" alt="">
    </div>
    <div class="item-contact">
        <div class="contant">
            <h3 class="maintitle">العنوان</h3>
            <h3 class="title">الرياض حى المروج 273</h3>
        </div>
    </div>
    <div class="item-contact">
        <div class="contant">
            <h3 class="maintitle">رقم الهاتف</h3>
            <h3 class="title"> +(966) 50 425 2545</h3>
        </div>
    </div>
    <div class="item-contact">
        <div class="contant">
            <h3 class="maintitle">البريد الإلكتروني</h3>
            <h3 class="title">aa.sd.1@hotmail.com</h3>
        </div>
    </div>
</div>